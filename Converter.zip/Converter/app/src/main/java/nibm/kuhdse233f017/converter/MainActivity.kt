package nibm.kuhdse233f017.converter

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var txtType: Spinner
    private lateinit var txtType2: Spinner
    private lateinit var txtValue: EditText
    private lateinit var btnClick: ImageView
    private lateinit var lblValue: TextView
    private lateinit var radioGroup: RadioGroup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        txtType = findViewById(R.id.Type1)
        txtType2 = findViewById(R.id.Type2)
        txtValue = findViewById(R.id.TxtValue)
        btnClick = findViewById(R.id.Btnclick)
        lblValue = findViewById(R.id.LblValue)
        radioGroup = findViewById(R.id.Rgroup)

        //  default spinner values
        configureSpinners("Distance")


        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.RadioDistance -> configureSpinners("Distance")
                R.id.RadioTemperature -> configureSpinners("Temperature")
                R.id.Radioweight -> configureSpinners("Weight")
            }
        }


        btnClick.setOnClickListener { Conversion() }
    }

    private fun configureSpinners(type: String) {
        val spinner1: List<String>
        val spinner2: List<String>

        when (type) {
            "Distance" -> {
                spinner1 = listOf("Kilometers", "Centimeters")
                spinner2 = listOf("Centimeters", "Kilometers")
            }
            "Temperature" -> {
                spinner1 = listOf("Fahrenheit", "Celsius")
                spinner2 = listOf("Celsius", "Fahrenheit")
            }
            "Weight" -> {
                spinner1 = listOf("Kilograms", "Grams")
                spinner2 = listOf("Grams", "Kilograms")
            }
            else -> return
        }

        val adapter1 = ArrayAdapter(this, android.R.layout.simple_spinner_item, spinner1)
        val adapter2 = ArrayAdapter(this, android.R.layout.simple_spinner_item, spinner2)

        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        txtType.adapter = adapter1
        txtType2.adapter = adapter2
    }

    private fun Conversion() {
        val valueStr = txtValue.text.toString()
        if (valueStr.isEmpty()) {
            lblValue.text = "Please Enter the value"
            return
        }

        val value = valueStr.toDoubleOrNull()
        if (value == null) {
            lblValue.text = "Invalid input!"
            return
        }

        val fromUnit = txtType.selectedItem.toString()
        val toUnit = txtType2.selectedItem.toString()
        val result = when {
            fromUnit == "Kilometers" && toUnit == "Centimeters" -> value * 100000
            fromUnit == "Centimeters" && toUnit == "Kilometers" -> value / 100000
            fromUnit == "Fahrenheit" && toUnit == "Celsius" -> (value - 32) * 5 / 9
            fromUnit == "Celsius" && toUnit == "Fahrenheit" -> (value * 9 / 5) + 32
            fromUnit == "Kilograms" && toUnit == "Grams" -> value * 1000
            fromUnit == "Grams" && toUnit == "Kilograms" -> value / 1000
            else -> {
                lblValue.text = "Invalid conversion!"
                return
            }
        }

        lblValue.text = "Converted Value: $result"
    }
}
